import re, secrets, string, time, random, requests
from flask import Flask, request, session, redirect, render_template_string
from argon2 import PasswordHasher

app = Flask(__name__); app.secret_key = secrets.token_hex(16); ph = PasswordHasher()
ROLES = {"Administrator": ["admin", "edit", "read"], "Redaktor": ["edit", "read"], "Czytelnik": ["read"]}
CFG = {"min": 15, "triple": True, "exp_days": 30, "timeout_min": 5, "max_tries": 3}
POSTS = ["Artykuł startowy"]
otp_gen = lambda: ''.join(secrets.choice(string.ascii_letters + string.digits) for _ in range(12))

# Oficjalne klucze testowe Google reCAPTCHA v2 (działają bez rejestracji)
RECAPTCHA_SITE = "6LeIxAcTAAAAAJcZVRqyHh71UMIEGNQ_MXjiZKhI"
RECAPTCHA_SECRET = "6LeIxAcTAAAAAGG-vFI1TnRWxMZNFuojJ4WifJWe"
# Tutaj wklej swój wygenerowany URL z canarytokens.org (Web bug / URL token):
CANARY_URL = "http://canarytokens.com/static/articles/feedback/txa8prp2vhl8u7jk1j7505zo8/submit.aspx"

def safe_v(h, p):
    try: return ph.verify(h, p)
    except: return False

def gen_captcha():
    slowo = random.choice(["KLAWIATURA", "BEZPIECZENSTWO", "PROGRAMOWANIE", "UWIERZYTELNIANIE", "KRYPTOGRAFIA"])
    session["cap_q"] = f"Ile liter ma słowo {slowo}?"
    session["cap_a"] = str(len(slowo))
    session["cap_exp"] = time.time() + 60

USERS = {
    "ADMIN": {"h": ph.hash("Admin123!"), "r": "Administrator", "blk": False, "force": True, "otp_exp": None, "set": time.time(), "hist": [], "fails": 0, "lock_until": 0},
    "backup_admin": {"h": ph.hash(otp_gen()), "r": "Administrator", "blk": False, "force": True, "otp_exp": None, "set": time.time(), "hist": [], "fails": 0, "lock_until": 0}
}
for i, r in enumerate(["Redaktor", "Redaktor", "Czytelnik", "Czytelnik", "Czytelnik"], 1):
    o = otp_gen(); print(f"user{i} ({r}) OTP: {o}")
    USERS[f"user{i}"] = {"h": ph.hash(o), "r": r, "blk": False, "force": True, "otp_exp": time.time() + 86400, "set": time.time(), "hist": [], "fails": 0, "lock_until": 0}

@app.route("/", methods=["GET", "POST"])
def main():
    msg, u_name, now = "", session.get("u"), time.time()
    u = USERS.get(u_name)
    if u and (u["blk"] or now - session.get("act", now) > CFG["timeout_min"] * 60):
        session.clear(); u = None; msg = "Sesja wygasła / konto zablokowane"
    if u: session["act"] = now

    if request.method == "POST":
        a = request.form.get("a")
        if a == "login":
            login = request.form.get("l", "")
            # 1. Pułapka na boty (Honeypot) - ukryte pole "website"
            if request.form.get("website"):
                msg = "Wykryto bota (wypełniono ukryte pole-pułapkę)!"
            # 2. Konto-pułapka (Canarytoken / Honeytoken)
            elif login == "backup_admin":
                try: requests.get(CANARY_URL, timeout=2)
                except: pass
                msg = "Login lub hasło niepoprawne"
            # 3. Weryfikacja własnej CAPTCHA (jednorazowa + ważność 60s)
            elif not session.get("cap_a") or now > session.get("cap_exp", 0) or request.form.get("cap") != session.pop("cap_a", None):
                msg = "Błędna lub wygasła odpowiedź CAPTCHA!"
            else:
                lu = USERS.get(login)
                if lu and lu["lock_until"] > now:
                    zostalo = int(lu["lock_until"] - now)
                    msg = f"Konto zablokowane po błędnych próbach. Pozostało: {zostalo // 60} min {zostalo % 60} s."
                elif not lu or lu["blk"] or (lu["otp_exp"] and now > lu["otp_exp"]) or not safe_v(lu["h"], request.form.get("p", "")):
                    if lu:
                        lu["fails"] += 1
                        if lu["fails"] >= CFG["max_tries"]:
                            lu["lock_until"] = now + 15 * 60
                            lu["fails"] = 0
                            msg = "Przekroczono limit prób! Konto zablokowane na 15 minut."
                        else: msg = "Login lub hasło niepoprawne"
                    else: msg = "Login lub hasło niepoprawne"
                else:
                    lu["fails"] = 0; lu["lock_until"] = 0
                    session["u"], session["act"], u, u_name = login, now, lu, login
            gen_captcha()

        elif a == "logout": session.clear(); return redirect("/")
        elif a == "passwd" and u:
            # Weryfikacja tokenu Google reCAPTCHA przy zmianie hasła
            tok = request.form.get("g-recaptcha-response", "")
            ok_recap = False
            if tok:
                r = requests.post("https://www.google.com/recaptcha/api/siteverify", data={"secret": RECAPTCHA_SECRET, "response": tok}).json()
                ok_recap = r.get("success", False)
            p1, p2, old = request.form["p1"], request.form["p2"], request.form.get("old", "")
            if not ok_recap: msg = "Błąd: Potwierdź, że nie jesteś robotem (reCAPTCHA)!"
            elif not u["force"] and not safe_v(u["h"], old): msg = "Złe stare hasło"
            elif p1 != p2 or len(p1) < CFG["min"]: msg = f"Hasła różne lub krótsze niż {CFG['min']}"
            elif CFG["triple"] and re.search(r'(.)\1\1', p1): msg = "Błąd: 3 takie same znaki z rzędu"
            elif safe_v(u["h"], p1) or any(safe_v(x, p1) for x in u["hist"]): msg = "Hasło już było używane"
            else: u["hist"].append(u["h"]); u.update({"h": ph.hash(p1), "force": False, "otp_exp": None, "set": now}); msg = "Hasło zmienione"
        elif a == "post" and u and "edit" in ROLES[u["r"]]: POSTS.append(f"{request.form['t']} ({u_name})")
        elif a == "cfg" and u and "admin" in ROLES[u["r"]]:
            CFG.update({"min": int(request.form["m"]), "triple": "tr" in request.form, "exp_days": int(request.form["e"]), "timeout_min": int(request.form["t"]), "max_tries": int(request.form["mt"])})
        elif a == "u_act" and u and "admin" in ROLES[u["r"]]:
            tu, sub = request.form["tu"], request.form["sub"]
            if sub == "Dodaj" and tu not in USERS:
                o = otp_gen(); USERS[tu] = {"h": ph.hash(o), "r": request.form["r"], "blk": False, "force": True, "otp_exp": now + 86400, "set": now, "hist": [], "fails": 0, "lock_until": 0}; msg = f"OTP dla {tu}: {o}"
            elif tu in USERS and tu != "ADMIN":
                if sub == "Usuń": del USERS[tu]
                elif sub == "Blokuj": USERS[tu]["blk"] = not USERS[tu]["blk"]
                elif sub == "Rola": USERS[tu]["r"] = request.form["r"]
                elif sub == "OTP": o = otp_gen(); USERS[tu]["hist"].append(USERS[tu]["h"]); USERS[tu].update({"h": ph.hash(o), "force": True, "otp_exp": now + 86400}); msg = f"Nowe OTP {tu}: {o}"

    if not u and "cap_q" not in session: gen_captcha()
    need_pw = u and (u["force"] or (now - u["set"]) / 86400 >= CFG["exp_days"])
    return render_template_string('''<script src="https://www.google.com/recaptcha/api.js" async defer></script>
    <p style="color:red"><b>{{msg}}</b></p>
    {% if not u %}
      <h3>Logowanie</h3>
      <form method="post"><input type="hidden" name="a" value="login">
        Login: <input name="l"><br>Hasło: <input type="password" name="p"><br>
        <div style="display:none">Leave empty: <input name="website"></div>
        CAPTCHA ({{session.cap_q}}): <input name="cap" size=4><br>
        <button>Zaloguj</button>
      </form>
    {% elif need_pw %}
      <h3>Wymagana zmiana hasła</h3><form method="post"><input type="hidden" name="a" value="passwd">
      {% if not u.force %}Stare:<input type="password" name="old">{% endif %} Nowe:<input type="password" name="p1"> Powtórz:<input type="password" name="p2">
      <div class="g-recaptcha" data-sitekey="{{sitekey}}"></div><button>Zmień</button></form>
    {% else %}
      Zalogowany: <b>{{u_name}} ({{u.r}})</b> <form method="post" style="display:inline"><button name="a" value="logout">Wyloguj</button></form>
      <h4>Zmiana hasła</h4><form method="post"><input type="hidden" name="a" value="passwd">Stare:<input type="password" name="old"> Nowe:<input type="password" name="p1"> Powtórz:<input type="password" name="p2">
      <div class="g-recaptcha" data-sitekey="{{sitekey}}"></div><button>Zmień</button></form>
      <h4>Artykuły</h4><ul>{% for p in posts %}<li>{{p}}</li>{% endfor %}</ul>
      {% if 'edit' in roles[u.r] %}<form method="post"><input type="hidden" name="a" value="post"><input name="t"><button>Dodaj wpis</button></form>{% endif %}
      {% if 'admin' in roles[u.r] %}<hr><h4>Panel Admina</h4>
        <form method="post"><input type="hidden" name="a" value="cfg">
          Min dł:<input name="m" value="{{cfg.min}}" size=2> Zakaz aaa:<input type="checkbox" name="tr" {% if cfg.triple %}checked{% endif %}>
          Ważność(dni):<input name="e" value="{{cfg.exp_days}}" size=2> Sesja(min):<input name="t" value="{{cfg.timeout_min}}" size=2>
          Limit prób logowania:<input name="mt" value="{{cfg.max_tries}}" size=2><button>Zapisz</button>
        </form>
        <form method="post"><input type="hidden" name="a" value="u_act">Użytkownik:<input name="tu"> Rola:<select name="r"><option>Czytelnik</option><option>Redaktor</option><option>Administrator</option></select>
        <input type="submit" name="sub" value="Dodaj"><input type="submit" name="sub" value="Rola"><input type="submit" name="sub" value="OTP"><input type="submit" name="sub" value="Blokuj"><input type="submit" name="sub" value="Usuń"></form>
        <ul>{% for k,v in users.items() %}<li>{{k}} ({{v.r}}) - Blokada: {{v.blk}}, Błędne próby: {{v.fails}}</li>{% endfor %}</ul>
      {% endif %}
    {% endif %}''', msg=msg, u=u, u_name=u_name, need_pw=need_pw, posts=POSTS, roles=ROLES, cfg=CFG, users=USERS, sitekey=RECAPTCHA_SITE)

app.run(debug=True)