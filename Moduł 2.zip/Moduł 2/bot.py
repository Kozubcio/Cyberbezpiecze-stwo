import requests, re

s = requests.Session()
url = "http://127.0.0.1:5000/"

print("--- TEST 1: Bot wypełniający wszystkie pola (wpada w Honeypot) ---")
r = s.post(url, data={"a": "login", "l": "ADMIN", "p": "123", "website": "http://spam.com", "cap": "10"})
print("Wynik:", re.findall(r'<b>(.*?)</b>', r.text)[0])

print("\n--- TEST 2: Bot bez rozwiązania CAPTCHA ---")
r = s.post(url, data={"a": "login", "l": "ADMIN", "p": "123", "website": "", "cap": "zla_odpowiedz"})
print("Wynik:", re.findall(r'<b>(.*?)</b>', r.text)[0])

print("\n--- TEST 3: Brute-force (przekroczenie limitu 3 prób i blokada 15 min) ---")
for i in range(1, 5):
    page = s.get(url).text
    slowo = re.search(r'słowo ([A-Z]+)\?', page).group(1)
    r = s.post(url, data={"a": "login", "l": "ADMIN", "p": f"zle_haslo_{i}", "website": "", "cap": str(len(slowo))})
    print(f"Próba {i}:", re.findall(r'<b>(.*?)</b>', r.text)[0])

print("\n--- TEST 4: Użycie konta-pułapki (Honeytoken: backup_admin) ---")
page = s.get(url).text
slowo = re.search(r'słowo ([A-Z]+)\?', page).group(1)
r = s.post(url, data={"a": "login", "l": "backup_admin", "p": "123", "website": "", "cap": str(len(slowo))})
print("Wynik:", re.findall(r'<b>(.*?)</b>', r.text)[0], "(Wysłano cichy alert Canarytoken!)")