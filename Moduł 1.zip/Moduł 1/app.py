import re
import secrets
import string
import time
from flask import Flask, request, session, redirect, render_template_string
from argon2 import PasswordHasher



######### !!! URUCHOMIENIE:
######### pip install -r requirements.txt && python app.py#####


app = Flask(__name__)
app.secret_key = "tajny_klucz_sesji"
ph = PasswordHasher()

# Role z wariantu 1
ROLES = {
    "Administrator": ["admin", "edit", "read"],
    "Redaktor": ["edit", "read"],
    "Czytelnik": ["read"]
}

CFG = {"min": 15, "triple": True, "exp_days": 30, "timeout_min": 5}
POSTS = ["Pierwszy artykul testowy"]s

def zrob_otp():
    znaki = string.ascii_letters + string.digits
    return ''.join(secrets.choice(znaki) for _ in range(12))

def sprawdz_haslo(hash_z_bazy, podane_haslo):
    try:
        return ph.verify(hash_z_bazy, podane_haslo)
    except:
        return False

USERS = {
    "ADMIN": {"h": ph.hash("Admin123!"), "r": "Administrator", "blk": False, "force": True, "otp_exp": None, "set": time.time(), "hist": []}
}

role_startowe = ["Redaktor", "Redaktor", "Czytelnik", "Czytelnik", "Czytelnik"]
for i in range(5):
    otp = zrob_otp()
    login = f"user{i+1}"
    rola = role_startowe[i]
    print(f"{login} ({rola}) haslo jednorazowe: {otp}")
    USERS[login] = {"h": ph.hash(otp), "r": rola, "blk": False, "force": True, "otp_exp": time.time() + 86400, "set": time.time(), "hist": []}

@app.route("/", methods=["GET", "POST"])
def main():
    msg = ""
    u_name = session.get("u")
    now = time.time()
    u = USERS.get(u_name)

    if u and (u["blk"] or now - session.get("act", now) > CFG["timeout_min"] * 60):
        session.clear()
        u = None
        msg = "Sesja wygasła lub konto zablokowane"
    if u:
        session["act"] = now

    if request.method == "POST":
        akcja = request.form.get("a")
        if akcja == "login":
            login = request.form["l"]
            haslo = request.form["p"]
            lu = USERS.get(login)
            if not lu or lu["blk"] or (lu["otp_exp"] and now > lu["otp_exp"]) or not sprawdz_haslo(lu["h"], haslo):
                msg = "Login lub hasło niepoprawne"
            else:
                session["u"] = login
                session["act"] = now
                u = lu
                u_name = login
        elif akcja == "logout":
            session.clear()
            return redirect("/")
        elif akcja == "passwd" and u:
            p1 = request.form["p1"]
            p2 = request.form["p2"]
            old = request.form.get("old", "")
            
            bylo_uzywane = sprawdz_haslo(u["h"], p1)
            for stary_hash in u["hist"]:
                if sprawdz_haslo(stary_hash, p1):
                    bylo_uzywane = True

            if not u["force"] and not sprawdz_haslo(u["h"], old):
                msg = "Złe stare hasło"
            elif p1 != p2 or len(p1) < CFG["min"]:
                msg = f"Hasła różne lub krótsze niż {CFG['min']}"
            elif CFG["triple"] and re.search(r'(.)\1\1', p1):
                msg = "Błąd: 3 takie same znaki z rzędu"
            elif bylo_uzywane:
                msg = "Hasło już było używane"
            else:
                u["hist"].append(u["h"])
                u["h"] = ph.hash(p1)
                u["force"] = False
                u["otp_exp"] = None
                u["set"] = now
                msg = "Hasło zmienione"
        elif akcja == "post" and u and "edit" in ROLES[u["r"]]:
            POSTS.append(f"{request.form['t']} (autor: {u_name})")
        elif akcja == "cfg" and u and "admin" in ROLES[u["r"]]:
            CFG["min"] = int(request.form["m"])
            CFG["triple"] = "tr" in request.form
            CFG["exp_days"] = int(request.form["e"])
            CFG["timeout_min"] = int(request.form["t"])
        elif akcja == "u_act" and u and "admin" in ROLES[u["r"]]:
            tu = request.form["tu"]
            sub = request.form["sub"]
            if sub == "Dodaj" and tu not in USERS:
                o = zrob_otp()
                USERS[tu] = {"h": ph.hash(o), "r": request.form["r"], "blk": False, "force": True, "otp_exp": now + 86400, "set": now, "hist": []}
                msg = f"OTP dla {tu}: {o}"
            elif tu in USERS and tu != "ADMIN":
                if sub == "Usuń": del USERS[tu]
                elif sub == "Blokuj": USERS[tu]["blk"] = not USERS[tu]["blk"]
                elif sub == "Rola": USERS[tu]["r"] = request.form["r"]
                elif sub == "OTP":
                    o = zrob_otp()
                    USERS[tu]["hist"].append(USERS[tu]["h"])
                    USERS[tu]["h"] = ph.hash(o)
                    USERS[tu]["force"] = True
                    USERS[tu]["otp_exp"] = now + 86400
                    msg = f"Nowe OTP {tu}: {o}"

    need_pw = u and (u["force"] or (now - u["set"]) / 86400 >= CFG["exp_days"])
    return render_template_string('''<p style="color:red">{{msg}}</p>
    {% if not u %}
      <form method="post"><input type="hidden" name="a" value="login">Login:<input name="l"> Hasło:<input type="password" name="p"><button>Zaloguj</button></form>
    {% elif need_pw %}
      <h3>Wymagana zmiana hasła</h3><form method="post"><input type="hidden" name="a" value="passwd">
      {% if not u.force %}Stare:<input type="password" name="old">{% endif %} Nowe:<input type="password" name="p1"> Powtórz:<input type="password" name="p2"><button>Zmień</button></form>
    {% else %}
      Zalogowany: <b>{{u_name}} ({{u.r}})</b> <form method="post" style="display:inline"><button name="a" value="logout">Wyloguj</button></form>
      <h4>Zmiana hasła</h4><form method="post"><input type="hidden" name="a" value="passwd">Stare:<input type="password" name="old"> Nowe:<input type="password" name="p1"> Powtórz:<input type="password" name="p2"><button>Zmień</button></form>
      <h4>Artykuły (Czytelnik/Redaktor/Admin)</h4><ul>{% for p in posts %}<li>{{p}}</li>{% endfor %}</ul>
      {% if 'edit' in roles[u.r] %}<form method="post"><input type="hidden" name="a" value="post"><input name="t"><button>Dodaj wpis (Redaktor/Admin)</button></form>{% endif %}
      {% if 'admin' in roles[u.r] %}<hr><h4>Panel Admina</h4>
        <form method="post"><input type="hidden" name="a" value="cfg">Min dł:<input name="m" value="{{cfg.min}}" size=2> Zakaz aaa:<input type="checkbox" name="tr" {% if cfg.triple %}checked{% endif %}> Ważność(dni):<input name="e" value="{{cfg.exp_days}}" size=2> Sesja(min):<input name="t" value="{{cfg.timeout_min}}" size=2><button>Zapisz</button></form>
        <form method="post"><input type="hidden" name="a" value="u_act">Użytkownik:<input name="tu"> Rola:<select name="r"><option>Czytelnik</option><option>Redaktor</option><option>Administrator</option></select>
        <input type="submit" name="sub" value="Dodaj"><input type="submit" name="sub" value="Rola"><input type="submit" name="sub" value="OTP"><input type="submit" name="sub" value="Blokuj"><input type="submit" name="sub" value="Usuń"></form>
        <ul>{% for k,v in users.items() %}<li>{{k}} ({{v.r}}) - Blokada: {{v.blk}}</li>{% endfor %}</ul>
      {% endif %}
    {% endif %}''', msg=msg, u=u, u_name=u_name, need_pw=need_pw, posts=POSTS, roles=ROLES, cfg=CFG, users=USERS)

app.run(debug=True)